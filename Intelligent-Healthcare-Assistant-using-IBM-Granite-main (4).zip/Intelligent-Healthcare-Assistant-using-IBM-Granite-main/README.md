# Intelligent-Healthcare-Assistant-using-IBM-Granite
technical architecture,project workflow,model selection and architecture,core functionalities,app.py development,design and develop the user interface,deployment,conclusion
