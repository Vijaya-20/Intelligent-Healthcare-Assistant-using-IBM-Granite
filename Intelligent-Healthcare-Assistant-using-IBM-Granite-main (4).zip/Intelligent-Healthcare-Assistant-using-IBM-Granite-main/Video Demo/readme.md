video domenstration of project 
